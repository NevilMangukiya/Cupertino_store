import 'package:adv_cupertino_app/screens/homePage.dart';
import 'package:flutter/cupertino.dart';

void main() {
  runApp(
    HomePage(),
  );
}
