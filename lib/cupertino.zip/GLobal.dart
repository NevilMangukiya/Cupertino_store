class Global {
  static List<Map> allCarts = [];
  static List value = [];
  static dynamic gst = 0;
  static dynamic subtotal = 0;
  static dynamic total = 0;
  static List<Map> allProducts = [
    {
      'image': "assets/images/braclet.jpeg",
      'name': 'Bracelet',
      'price': 11198,
    },
    {
      'image': "assets/images/lucky.png",
      'name': 'Gold Lucky',
      'price': 3335,
    },
    {
      'image': "assets/images/shirt.jpeg",
      'name': 'Shirt',
      'price': 355,
    },
    {
      'image': "assets/images/pants.jpeg",
      'name': 'Pants',
      'price': 425,
    },
    {
      'image': "assets/images/key.jpeg",
      'name': 'Key Chain',
      'price': 25,
    },
    {
      'image': "assets/images/belt.jpeg",
      'name': 'Belt',
      'price': 400,
    },
    {
      'image': "assets/images/bag.png",
      'name': 'Leather Bag',
      'price': 600,
    },
    {
      'image': "assets/images/napkin.jpeg",
      'name': 'Hand cleaner',
      'price': 20,
    },
    {
      'image': "assets/images/wallet.jpeg",
      'name': 'Wallet',
      'price': 800,
    },
    {
      'image': "assets/images/braclet.jpeg",
      'name': 'Gold braclet',
      'price': 80,
    },
    {
      'image': "assets/images/lucky.jpeg",
      'name': 'GOLD Lucky',
      'price': 80,
    },
  ];
}
